/*
 *
 * Copyright (c) 2021 Melvin Jones Repol (mrepol742.github.io). All rights reserved.
 *
 * License under the GNU General Public License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * Unless required by the applicable law or agreed in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mrepol742.webvium.content;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;

import com.mrepol742.webvium.annotation.release.Keep;

public class Resources {
    @Keep
    private Resources() {
    }

    public static Drawable a(Context a, int i) {
        return a.getDrawable(i);
    }

    @SuppressWarnings("deprecation")
    public static int b(Context a, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            return a.getColor(i);
        }
        return a.getResources().getColor(i);
    }

    public static Bitmap c(Context context, int res) {
        Drawable drawable = a(context, res);
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return bitmap;
    }

    public static Boolean d(Context ct, int i) {
        return ct.getResources().getBoolean(i);
    }

    public static int e(Context ct, int i) {
        return ct.getResources().getInteger(i);
    }


    public static Drawable f(int i, float[] fl, int j) {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(i);
        shape.setCornerRadii(fl);
        shape.setColor(j);
        return shape;
    }

}
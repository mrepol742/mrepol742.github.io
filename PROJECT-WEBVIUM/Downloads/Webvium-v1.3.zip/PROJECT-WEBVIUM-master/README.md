<p align="center">
 <img width="100px" src="https://github.com/mrepol742/PROJECT-WEBVIUM/blob/master/app/src/main/res/mipmap-xxxhdpi/c.png" align="center" alt="PROJECT-WEBVIUM" />
 <h2 align="center">PROJECT-WEBVIUM</h2>
 <p align="center">Lightweight, material design and full-featured Android Browser</p>
</p>

<p align="center">
<img src="https://img.shields.io/badge/Java-8-blue.svg">
  <img src="https://img.shields.io/badge/XML-blue.svg"> 
  <img src="https://img.shields.io/badge/HTML-5-blue.svg">
  <img src="https://img.shields.io/badge/CSS-blue.svg"> 
  <img src="https://img.shields.io/badge/JavaScript-blue.svg">
  <img src="https://img.shields.io/badge/SQLite-blue.svg">
</p>
<p align="center">
 <img src="https://github.com/mrepol742/PROJECT-WEBVIUM/actions/workflows/gradle.yml/badge.svg" />
  <img src="https://img.shields.io/github/issues/mrepol742/PROJECT-WEBVIUM?color=0088ff" />
  <img src="https://img.shields.io/github/issues-pr/mrepol742/PROJECT-WEBVIUM?color=0088ff" />
</p>

<p align="center">
<img src="https://raw.githubusercontent.com/mrepol742/mrepol742.github.io/main/images/webvium_light_main.webp" width="190"> <img src="https://raw.githubusercontent.com/mrepol742/mrepol742.github.io/main/images/webvium_dark_main.webp" width="190">
</p>

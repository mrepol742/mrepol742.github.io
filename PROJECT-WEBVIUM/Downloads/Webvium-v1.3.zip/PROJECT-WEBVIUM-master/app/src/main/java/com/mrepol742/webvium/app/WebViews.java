/*
 *
 * Copyright (c) 2021 Melvin Jones Repol (mrepol742.github.io). All rights reserved.
 *
 * License under the GNU General Public License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * Unless required by the applicable law or agreed in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mrepol742.webvium.app;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import com.mrepol742.webvium.annotation.Development;
import com.mrepol742.webvium.annotation.release.Keep;
import com.mrepol742.webvium.app.main.MainWebView;
import com.mrepol742.webvium.content.Package;

import java.util.ArrayList;

public class WebViews extends MainWebView {
    @Development
    public final ArrayList<ForwardBackwardHistoryDataModel> w4 = new ArrayList<>();

    @Keep
    public WebViews(Context ct) {
        super(ct);
    }

    @Keep
    public WebViews(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Keep
    public WebViews(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        if (visibility != View.GONE) super.onWindowVisibilityChanged(View.VISIBLE);
    }

    @Override
    @Development
    public void goBack() {
        w4.add(new ForwardBackwardHistoryDataModel("", getUrl()));
        super.goBack();
    }

    @Override
    @Development
    public void goForward() {
        w4.add(new ForwardBackwardHistoryDataModel(getUrl(), ""));
        super.goForward();
    }

    public void load(String baseUrl, String html) {
        loadDataWithBaseURL(Package.c(), html, "text/html", getTextEncoding(), baseUrl);
    }
}
/*
 *
 * Copyright (c) 2021 Melvin Jones Repol (mrepol742.github.io). All rights reserved.
 *
 * License under the GNU General Public License, Version 3.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * Unless required by the applicable law or agreed in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.mrepol742.webvium;

import com.mrepol742.webvium.annotation.ObjectSerializability;

import java.io.Serializable;

@ObjectSerializability
public class DDMS implements Serializable {
    public final String b;
    public final String d;
    public final int e4;
    public final String f;
    public final String g;

    public DDMS(String al, String al2, int a13, String a14, String a15) {
        b = al;
        d = al2;
        e4 = a13;
        f = a14;
        g = a15;
    }
}

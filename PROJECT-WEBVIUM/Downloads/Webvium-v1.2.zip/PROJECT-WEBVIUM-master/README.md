# Webvium | Ultra lightweight, material design and full-featured Android Browser.
![Java 8](https://img.shields.io/badge/Java-8-blue.svg) ![XML](https://img.shields.io/badge/XML-blue.svg) ![HTML](https://img.shields.io/badge/HTML-blue.svg) ![CSS](https://img.shields.io/badge/CSS-blue.svg) ![JavaScript](https://img.shields.io/badge/JavaScript-blue.svg) ![PHP](https://img.shields.io/badge/PHP-blue.svg) ![SQLite](https://img.shields.io/badge/SQLite-blue.svg) 

Webvium was made possible by the Webview and Chromium open source project.

![Build Workflow](https://github.com/mrepol742/PROJECT-WEBVIUM/actions/workflows/gradle.yml/badge.svg)

Light Theme                |  Dark Theme
:-------------------------:|:-------------------------:
<img src="https://raw.githubusercontent.com/mrepol742/mrepol742.github.io/main/images/webvium_light_main.webp" width="190">   |   <img src="https://raw.githubusercontent.com/mrepol742/mrepol742.github.io/main/images/webvium_dark_main.webp" width="190">

# Installation
## Requirements

Required:
* Android System Webview and/or Chrome
* Android version 5 or newer

# Build
## Requirements

Required
* Android Gradle Plugin version 4.1.3
* Android SDK version 30
* Gradle version 6.8.1

# Download
git clone https://github.com/mrepol742/PROJECT-WEBVIUM

# Update
The project is under heavy development, new improvements and features comes up. Be sure to update often.
Occasionally we release update weekly.

## Update Source Code

```
cd PROJECT-WEBVIUM
git pull
```

## Update The App
Visit [PROJECT-WEBVIUM](https://mrepol742.github.io/PROJECT-WEBVIUM) and download the latest version or
```
* Open Webvium app
* Go to Settings
* Then About
* And Check Update
```

# License
The PROJECT-WEBVIUM is under a GPL v3.0 license.
Please see [LICENSE](LICENSE) for more details.

# Project
* [PROJECT-WEBVIUM](https://github.com/mrepol742/PROJECT-WEBVIUM)
* [mrepol742.github.io](https://github.com/mrepol742/mrepol742.github.io)
* [Server](https://github.com/mrepol742/Server)
